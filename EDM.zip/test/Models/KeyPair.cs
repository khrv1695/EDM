﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EDM.Models
{
    public class KeyPair
    {
        public KeyPair(string id,String name)
        {
            this.ID = id;
            this.Name = name;
        }
        public String ID { get; set; }
        public String Name { get; set; }
    }
}
