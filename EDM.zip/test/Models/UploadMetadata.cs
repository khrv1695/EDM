﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EDM.Models
{
    public class UploadMetadata
    {
        
        public String DestinationType { get; set; }
        public String Destination { get; set; }
        public String Schema { get; set; }
        public ICollection<IFormFile> Files { get; set; }
    }
}
