export const environment = {
  production: true,
  APIURL: ''
};
