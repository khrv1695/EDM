export interface UploadMetadata {
    DestinationType: String;
    Destination: String;
    Schema: String;
    Files: File
} 