export interface KeyPair {
    id: string;
    name: string;
}