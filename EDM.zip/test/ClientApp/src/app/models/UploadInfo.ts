import { KeyPair } from './KeyPair';

export class UploadInfo {
    constructor() {
        this.DestinationType = [];
        this.Destination = [];
        this.Schema = [];
    }

    DestinationType: KeyPair[];
    Destination: KeyPair[];
    Schema: KeyPair[];
}