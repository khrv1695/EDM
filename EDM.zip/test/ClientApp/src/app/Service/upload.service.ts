import { UploadMetadata } from './../models/UploadMetadata';
import { UploadInfo } from './../models/UploadInfo';
import { environment } from './../../environments/environment';
import { Injectable } from '@angular/core';
import { KeyPair } from '../models/KeyPair';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UploadService {
  Upload(value: UploadMetadata) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    const formData = new FormData();

    for (const key of Object.keys(value)) {
      const val = value[key];
      formData.append(key, val);
    }


    return this.http.post(environment.APIURL + 'Upload/UploadFile', formData, { headers })
  }

  constructor(private http: HttpClient) { }

  GetDestinationTypes(): Observable<KeyPair[]> {
    return this.http.get(environment.APIURL + 'Master/GetDestinationTypes') as Observable<KeyPair[]>
  }
  GetSchemasByDestination(Destination: any): Observable<KeyPair[]> {
    return this.http.get(environment.APIURL + 'Master/GetSchemasByDestination?Destination=' + Destination) as Observable<KeyPair[]>
  }
  GetDestinationsByType(DestinationType: any): Observable<KeyPair[]> {
    return this.http.get(environment.APIURL + 'Master/GetDestinationsByType?DestinationType=' + DestinationType) as Observable<KeyPair[]>
  }
}
