import { environment } from './../../environments/environment';
import { UploadInfo } from './../models/UploadInfo';
import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UploadService } from '../Service/upload.service';
import { HttpRequest, HttpEventType, HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss']
})
export class UploadComponent implements OnInit {

  UploadInfoForm: FormGroup;
  uploadInfo: UploadInfo;
  message: any;
  progress: number;
  constructor(private fb: FormBuilder, private http: HttpClient, private uploadSVC: UploadService) { }

  @ViewChild('file', null)
  fileInput: ElementRef;

  ngOnInit() {
    this.UploadInfoForm = this.fb.group({
      DestinationType: ['', Validators.required],
      Destination: ['', Validators.required],
      Schema: ['', Validators.required],
      Files: ['', Validators.required]
    })
    this.uploadInfo = new UploadInfo();
    this.uploadSVC.GetDestinationTypes().subscribe(st => this.uploadInfo.DestinationType = st);
  }

  onDTChange() {
    this.uploadSVC.GetDestinationsByType(this.UploadInfoForm.value.DestinationType).subscribe(st => this.uploadInfo.Destination = st);
  }

  onDestinationChange() {
    this.uploadSVC.GetSchemasByDestination(this.UploadInfoForm.value.Destination).subscribe(st => this.uploadInfo.Schema = st);
  }
  upload() {
    this.uploadSVC.Upload(this.UploadInfoForm.value).subscribe(r => {
      this.UploadInfoForm.reset();
      this.fileInput.nativeElement.value = "";
      alert('fileUploaded Successfully')
    });
  }

  loadFile(files) {
    this.UploadInfoForm.patchValue({ 'Files': files[0] });
  }
} 
