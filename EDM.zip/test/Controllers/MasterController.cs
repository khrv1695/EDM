﻿using EDM.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EDM.Controllers
{
    //[ApiController]
    //[Route("[controller]")]
    //[EnableCors("AllowUIOrigin")]
    public class MasterController : ControllerBase
    { 
        [HttpGet] 
        public IEnumerable<KeyPair> GetDestinationTypes()
        {
            var ls = new List<KeyPair>();
            ls.Add(new KeyPair("1", "MSSQL"));
            ls.Add(new KeyPair("2", "MySQL"));
            ls.Add(new KeyPair("3", "Oracle"));
            ls.Add(new KeyPair("4", "MongoDb"));
            return ls;
        }
        [HttpGet] 
        public IEnumerable<KeyPair> GetDestinationsByType(string DestinationType)
        {
            var ls = new List<KeyPair>();
            ls.Add(new KeyPair("1", "Master"));
            ls.Add(new KeyPair("2", "HR"));
            ls.Add(new KeyPair("3", "EDM"));
            ls.Add(new KeyPair("4", "Test"));
            return ls;
        }
        public IEnumerable<KeyPair> GetSchemasByDestination(String Destination)
        {
            var ls = new List<KeyPair>();
            ls.Add(new KeyPair("1", "PersonalInfo"));
            ls.Add(new KeyPair("2", "Contact")); 
            return ls;
        }
    }
}
