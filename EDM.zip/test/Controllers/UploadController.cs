﻿using EDM.BL;
using EDM.DL;
using EDM.Models;
using ExcelDataReader;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EDM.Controllers
{
    public class UploadController : ControllerBase
    {
        [HttpPost]
        public void UploadFile([FromForm]UploadMetadata uploadMetadata)
        {
            foreach (var file in uploadMetadata.Files)
            {
                //Backup
                string localFilePath = new FileManager().saveFileToLocal(file);
                //Decide Repo based on DestinationType using DI
                new MSSQLRepo().processFile(localFilePath, uploadMetadata);
            }
        }
    }
}
