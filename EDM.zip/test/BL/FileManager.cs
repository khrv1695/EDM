﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EDM.BL
{
    public class FileManager
    {
        public string saveFileToLocal(IFormFile file)
        {
            string localFilePath = String.Join("\\", AppDomain.CurrentDomain.BaseDirectory.Split("\\").SkipLast(2)) + "\\Resources\\" + file.FileName;
            using (var stream = new FileStream(localFilePath, FileMode.Create))
            {
                file.CopyTo(stream);
            }
            return localFilePath;
        }
    }
}
